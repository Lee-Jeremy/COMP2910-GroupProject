/**
 * Display Crown
 */
function displayCrown() {
    getId('crown').style.display = "block";
}